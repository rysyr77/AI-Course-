"""Tests for the local Flask application."""
