module.exports = {
  content: ["./index.html", "./src/scripts/**/*.js"],
  theme: {
    extend: {
      colors: {
        campus: {
          navy: "#101d3b",
          blue: "#1e4788",
          gold: "#e9bc6e",
          cyan: "#72d5ff"
        }
      },
      fontFamily: {
        sans: ["Noto Sans Arabic", "Segoe UI", "Tahoma", "Arial", "sans-serif"]
      }
    }
  },
  plugins: []
};
