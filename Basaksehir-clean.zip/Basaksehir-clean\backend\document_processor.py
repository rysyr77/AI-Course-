"""Validated university-document ingestion for ChromaDB."""
from __future__ import annotations
import hashlib, json, re, uuid
from pathlib import Path
from typing import Any
from .config import ALLOWED_EXTENSIONS, MAX_UPLOAD_SIZE, UPLOAD_DIR, VECTOR_STORE_DIR, DOCUMENT_COLLECTION_NAME, EMBEDDING_MODEL, EMBEDDING_DEVICE
from .db import now, save_document
from .rag_engine import encode_texts

def clean_text(text: str) -> str:
    text = text.replace('\x00', ' ')
    return re.sub(r'[ \t]+', ' ', re.sub(r'\n{3,}', '\n\n', text)).strip()

def extract_pages(path: Path) -> list[tuple[int, str]]:
    suffix = path.suffix.lower()
    if suffix == '.pdf':
        import fitz
        with fitz.open(path) as doc: return [(i + 1, clean_text(page.get_text())) for i, page in enumerate(doc)]
    raw = path.read_text(encoding='utf-8-sig')
    if suffix == '.json':
        payload = json.loads(raw)
        raw = json.dumps(payload, ensure_ascii=False, indent=2)
    return [(1, clean_text(raw))]

def chunk_text(text: str, size: int = 900, overlap: int = 120) -> list[str]:
    words = text.split()
    if not words: return []
    chunks, start = [], 0
    while start < len(words):
        chunks.append(' '.join(words[start:start + size]))
        start += max(1, size - overlap)
    return chunks

def process_document(path: Path, metadata: dict[str, Any]) -> dict[str, Any]:
    if path.suffix.lower() not in ALLOWED_EXTENSIONS: raise ValueError('نوع الملف غير مدعوم')
    if path.stat().st_size > MAX_UPLOAD_SIZE: raise ValueError('حجم الملف أكبر من الحد المسموح')
    pages = extract_pages(path)
    rows = []
    for page_no, text in pages:
        for index, chunk in enumerate(chunk_text(text)):
            rows.append((page_no, index, chunk))
    if not rows: raise ValueError('لم يتم العثور على نص قابل للفهرسة')
    try:
        import chromadb
        from sentence_transformers import SentenceTransformer
    except ImportError as exc: raise RuntimeError('ثبّت متطلبات RAG أولاً') from exc
    VECTOR_STORE_DIR.mkdir(parents=True, exist_ok=True)
    client = chromadb.PersistentClient(path=str(VECTOR_STORE_DIR))
    try: collection = client.get_collection(DOCUMENT_COLLECTION_NAME)
    except Exception: collection = client.create_collection(DOCUMENT_COLLECTION_NAME, metadata={'hnsw:space':'cosine'})
    doc_id = metadata.get('id') or uuid.uuid4().hex
    old = collection.get(where={'file_id': doc_id}, include=[])
    if old.get('ids'): collection.delete(ids=old['ids'])
    model = SentenceTransformer(EMBEDDING_MODEL, device=EMBEDDING_DEVICE)
    embeddings = encode_texts(model, [r[2] for r in rows], task='passage').tolist()
    base = {k: str(metadata.get(k, '')) for k in ('filename','source_name','source_type','section','academic_year','semester','status')}
    metas = [{**base, 'file_id': doc_id, 'page': str(page), 'updated_at': str(metadata.get('updated_at') or now()), 'approved': 'true' if metadata.get('status') == 'approved' else 'false'} for page, _, _ in rows]
    ids = [f'{doc_id}-{i}' for i in range(len(rows))]
    collection.add(ids=ids, documents=[r[2] for r in rows], embeddings=embeddings, metadatas=metas)
    row = {**metadata, 'id': doc_id, 'updated_at': metadata.get('updated_at') or now(), 'chunk_count': len(rows)}
    save_document(row)
    return row
