"""Backend package for the local AI Course Assistant."""
