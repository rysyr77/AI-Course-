# مساعد المقررات الجامعي الذكي — Başakşehir University

هذا المشروع تطوير للموقع الأصلي، ويحافظ على واجهته وشعاره وألوانه. أصبح الآن نظام RAG مبسطًا: يحوّل السؤال إلى embedding متعدد اللغات، يبحث في ChromaDB داخل المقاطع المعتمدة، ثم يرسل السؤال والسياق المسترجع فقط إلى Gemini لصياغة إجابة مع المصادر.

## التشغيل السهل على Windows 11

هذه النسخة تحتوي على ملفات جاهزة. فك الضغط ثم افتح مجلد `AI-Course-Assistant-Basaksehir` واضغط مرتين على:

```text
setup_windows.bat
```

سيثبت السكربت Python 3.12 عند الحاجة، ينشئ البيئة الافتراضية، يثبت نسخ المكتبات المتوافقة، ويبني الفهرس. بعد اكتماله اضغط مرتين على:

```text
start_windows.bat
```

سيطلب كلمة مرور لوحة الإدارة ويفتح الموقع تلقائيًا. الرابط الصحيح هو `http://127.0.0.1:7860`، وليس Live Server على المنفذ 5500.

### التشغيل اليدوي البديل

```powershell
cd AI-Course-Assistant-Basaksehir
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
$env:GEMINI_API_KEY="ضع_مفتاح_Gemini_هنا"
$env:ADMIN_PASSWORD="كلمة_مرور_قوية"
python -m backend.make_embeddings --overwrite
python -m backend.app
```

افتح `http://127.0.0.1:7860`، ولوحة الإدارة في `http://127.0.0.1:7860/admin`. يمكن الحصول على مفتاح Gemini من Google AI Studio، ويجب وضعه في Secret على الاستضافة لا في Git.

## إضافة ملفات الجامعة

سجّل الدخول إلى `/admin`، ارفع PDF نصيًا أو TXT أو Markdown أو JSON، وأدخل بيانات المصدر. الملف يُفهرس كمسودة؛ راجعه ثم اضغط «اعتماد». لا تبحث واجهة الطلاب إلا في الملفات المعتمدة. عند إعادة رفع نسخة أحدث، احذف النسخة القديمة أو استخدم معرفًا جديدًا، ثم اعتمد الجديدة. ملفات PDF الممسوحة ضوئيًا تحتاج OCR خارجيًا قبل الرفع في هذه النسخة؛ PyMuPDF يقرأ PDF النصي.

## الاستضافة على Hugging Face Spaces

أنشئ Space جديدًا من نوع Docker، ارفع المستودع، ثم أضف `GEMINI_API_KEY` و`ADMIN_PASSWORD` من Settings → Variables and secrets. يستخدم Dockerfile المنفذ `PORT` (وفي Spaces غالبًا 7860) وGunicorn. التخزين المحلي في Space قد يكون مؤقتًا؛ لذلك احتفظ بملفات `backend/data/uploads` ونسخة قاعدة المعرفة في مستودع خاص أو Volume، وأعد الفهرس عند فقدان التخزين المؤقت. الخدمة المجانية ليست بلا حدود وقد تتأثر بالـCPU والحصة المجانية لـGemini.

## الاختبارات

```powershell
python -m unittest discover -s backend/tests -v
```

اختبارات الواجهة تستخدم مساعدًا وهميًا ولا تدّعي أنها إجابات Gemini. اختبر الإنتاج يدويًا بمفتاح حقيقي: سؤال موجود، سؤال عربي عامي، سؤال إنجليزي، سؤال خارج الملفات، ملف مسودة، ملف معتمد، حذف ملف، وغياب المفتاح.

## الملفات المهمة

- `backend/llm.py`: عميل Gemini ورسائل الفشل الآمنة.
- `backend/document_processor.py`: التحقق والاستخراج والتقسيم والفهرسة.
- `backend/rag_engine.py`: البحث الدلالي وعتبة التشابه والسياق الموثوق.
- `backend/db.py`: SQLite للملفات والأسئلة غير المجابة.
- `admin.html`: لوحة الإدارة المنفصلة.
- `.env.example`: أسماء الإعدادات دون أسرار.

إذا لم يوجد `GEMINI_API_KEY` أو تعذر الاتصال، يعيد الخادم رسالة إعداد/فشل واضحة ولا يخترع إجابة.
