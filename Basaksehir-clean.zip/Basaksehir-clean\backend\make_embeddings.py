"""Validate Q&A JSON and build the local Chroma vector collection."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from .config import COLLECTION_NAME, DATA_PATH, EMBEDDING_DEVICE, EMBEDDING_MODEL, VECTOR_STORE_DIR
from .rag_engine import encode_texts

MAX_ENTRIES = 20_000
MAX_QUESTION_CHARS = 2_000
MAX_ANSWER_CHARS = 10_000


def load_knowledge(path: Path) -> list[dict[str, Any]]:
    if not path.is_file():
        raise ValueError(f"Knowledge JSON file not found: {path}")
    if path.stat().st_size > 50 * 1024 * 1024:
        raise ValueError("Knowledge JSON file is larger than the 50 MiB safety limit")

    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON at line {exc.lineno}, column {exc.colno}") from exc

    if not isinstance(payload, list) or not payload:
        raise ValueError("The JSON root must be a non-empty array of Q&A objects")
    if len(payload) > MAX_ENTRIES:
        raise ValueError(f"The JSON may contain no more than {MAX_ENTRIES} entries")

    entries: list[dict[str, Any]] = []
    seen_ids: set[str] = set()
    for index, row in enumerate(payload, start=1):
        if not isinstance(row, dict):
            raise ValueError(f"Entry {index} must be a JSON object")

        entry_id = row.get("id")
        question = row.get("question")
        answer = row.get("answer")
        if not isinstance(entry_id, str) or not entry_id.strip():
            raise ValueError(f"Entry {index} needs a non-empty string 'id'")
        entry_id = entry_id.strip()
        if entry_id in seen_ids:
            raise ValueError(f"Duplicate id '{entry_id}' in entry {index}")
        seen_ids.add(entry_id)

        if not isinstance(question, str) or not question.strip():
            raise ValueError(f"Entry {index} needs a non-empty string 'question'")
        if len(question.strip()) > MAX_QUESTION_CHARS:
            raise ValueError(f"Question in entry {index} exceeds {MAX_QUESTION_CHARS} characters")
        if not isinstance(answer, str) or not answer.strip():
            raise ValueError(f"Entry {index} needs a non-empty string 'answer'")
        if len(answer.strip()) > MAX_ANSWER_CHARS:
            raise ValueError(f"Answer in entry {index} exceeds {MAX_ANSWER_CHARS} characters")

        keywords = row.get("keywords", [])
        if not isinstance(keywords, list) or any(not isinstance(item, str) for item in keywords):
            raise ValueError(f"'keywords' in entry {index} must be an array of strings")
        if len(keywords) > 30 or any(len(item) > 200 for item in keywords):
            raise ValueError(f"'keywords' in entry {index} exceeds the supported size")

        category = row.get("category", "عام")
        if not isinstance(category, str):
            raise ValueError(f"'category' in entry {index} must be a string")

        normalized = {
            "id": entry_id,
            "question": question.strip(),
            "answer": answer.strip(),
            "keywords": [item.strip() for item in keywords if item.strip()],
            "category": category.strip() or "عام",
        }
        entries.append(normalized)

    return entries


def collection_names(client: Any) -> set[str]:
    """Support Chroma releases that return names or collection objects."""
    names: set[str] = set()
    for collection in client.list_collections():
        names.add(str(getattr(collection, "name", collection)))
    return names


def build_collection(data_path: Path, *, overwrite: bool = False) -> int:
    entries = load_knowledge(data_path)

    try:
        import chromadb
        from sentence_transformers import SentenceTransformer
    except ImportError as exc:
        raise RuntimeError(
            "Install dependencies first with: python -m pip install -r requirements.txt"
        ) from exc

    VECTOR_STORE_DIR.mkdir(parents=True, exist_ok=True)
    client = chromadb.PersistentClient(path=str(VECTOR_STORE_DIR))
    if COLLECTION_NAME in collection_names(client) and not overwrite:
        raise ValueError(
            f"Collection '{COLLECTION_NAME}' already exists. Use --overwrite to replace it."
        )

    model = SentenceTransformer(EMBEDDING_MODEL, device=EMBEDDING_DEVICE)
    documents = [
        item["question"] + (" " + " ".join(item["keywords"]) if item["keywords"] else "")
        for item in entries
    ]
    embeddings = encode_texts(model, documents, task="passage").tolist()
    metadatas = [
        {
            "question": item["question"],
            "answer": item["answer"],
            "category": item["category"],
            "keywords": " ".join(item["keywords"]),
        }
        for item in entries
    ]

    if COLLECTION_NAME in collection_names(client):
        client.delete_collection(name=COLLECTION_NAME)

    collection = client.create_collection(
        name=COLLECTION_NAME,
        metadata={"hnsw:space": "cosine"},
    )
    collection.add(
        ids=[item["id"] for item in entries],
        documents=documents,
        embeddings=embeddings,
        metadatas=metadatas,
    )
    return collection.count()


def main() -> int:
    parser = argparse.ArgumentParser(description="Build local course Q&A embeddings in ChromaDB")
    parser.add_argument("--data", type=Path, default=DATA_PATH, help="Path to a Q&A JSON file")
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Replace the existing course_qa collection after embeddings are ready",
    )
    args = parser.parse_args()

    try:
        count = build_collection(args.data.expanduser().resolve(), overwrite=args.overwrite)
    except (ValueError, RuntimeError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    print(f"Indexed {count} Q&A entries in Chroma collection '{COLLECTION_NAME}'.")
    print(f"Vector store: {VECTOR_STORE_DIR}")
    print("No questions or embeddings are sent to a paid API.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
