"""Unit tests for data validation and retrieval decisions without ML packages."""

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from backend.make_embeddings import load_knowledge
from backend.rag_engine import RAGAssistant, encode_texts, normalize_question, prepare_text


class FakeVector:
    def tolist(self):
        return [0.1, 0.2, 0.3]


class FakeBatch:
    def __getitem__(self, index):
        if index != 0:
            raise IndexError(index)
        return FakeVector()


class FakeModel:
    def __init__(self):
        self.options = None

    def encode(self, _texts, **kwargs):
        self.options = kwargs
        return FakeBatch()


class FakeCollection:
    def __init__(self, distance):
        self.distance = distance

    def get(self, **_kwargs):
        return {"metadatas": []}

    def count(self):
        return 1

    def query(self, **_kwargs):
        return {
            "ids": [["ai-001"]],
            "metadatas": [[{"question": "ما هو AI؟", "answer": "إجابة محفوظة"}]],
            "distances": [[self.distance]],
        }


class ExactCollection(FakeCollection):
    def __init__(self, distance=0.9):
        super().__init__(distance)
        self.query_called = False

    def get(self, **_kwargs):
        return {"metadatas": [{"question": "ما معنى RAG؟", "answer": "إجابة RAG الدقيقة"}]}

    def query(self, **_kwargs):
        self.query_called = True
        return super().query()


class RAGTests(unittest.TestCase):
    def test_loads_valid_q_and_a_json(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "knowledge.json"
            path.write_text(
                json.dumps([{"id": "q1", "question": "سؤال", "answer": "جواب"}], ensure_ascii=False),
                encoding="utf-8",
            )
            entries = load_knowledge(path)
        self.assertEqual(entries[0]["id"], "q1")
        self.assertEqual(entries[0]["keywords"], [])

    def test_duplicate_ids_are_rejected(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "knowledge.json"
            row = {"id": "same", "question": "سؤال", "answer": "جواب"}
            path.write_text(json.dumps([row, row], ensure_ascii=False), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "Duplicate id"):
                load_knowledge(path)

    def test_e5_text_has_correct_task_prefix(self):
        self.assertEqual(
            prepare_text("نص", task="query", model_name="intfloat/multilingual-e5-small"),
            "query: نص",
        )
        self.assertEqual(
            prepare_text("نص", task="passage", model_name="intfloat/multilingual-e5-small"),
            "passage: نص",
        )

    def test_question_normalization_ignores_punctuation_and_diacritics(self):
        self.assertEqual(normalize_question("ما مَعنى RAG؟"), normalize_question("ما معنى RAG"))

    def test_exact_arabic_question_is_returned_before_vector_search(self):
        assistant = RAGAssistant.__new__(RAGAssistant)
        assistant.model = FakeModel()
        assistant.collection = ExactCollection()
        result = assistant.answer("ما معنى RAG؟")
        self.assertTrue(result["matched"])
        self.assertEqual(result["answer"], "إجابة RAG الدقيقة")
        self.assertEqual(result["similarity"], 1.0)
        self.assertFalse(assistant.collection.query_called)

    def test_cosine_search_returns_match_under_threshold(self):
        assistant = RAGAssistant.__new__(RAGAssistant)
        assistant.model = FakeModel()
        assistant.collection = FakeCollection(distance=0.1)
        with patch("backend.rag_engine.RAG_MAX_DISTANCE", 0.45):
            result = assistant.answer("سؤال الطالب")
        self.assertTrue(result["matched"])
        self.assertEqual(result["answer"], "إجابة محفوظة")
        self.assertEqual(result["similarity"], 0.9)
        self.assertEqual(result["source"], "ما هو AI؟")

    def test_cosine_search_rejects_distant_match(self):
        assistant = RAGAssistant.__new__(RAGAssistant)
        assistant.model = FakeModel()
        assistant.collection = FakeCollection(distance=0.7)
        with patch("backend.rag_engine.RAG_MAX_DISTANCE", 0.45):
            result = assistant.answer("سؤال مختلف")
        self.assertFalse(result["matched"])
        self.assertIsNone(result["source"])
        self.assertEqual(result["similarity"], 0.3)

    def test_embeddings_are_normalized(self):
        model = FakeModel()
        encoded = encode_texts(model, ["سؤال"], task="query")
        self.assertEqual(encoded[0].tolist(), [0.1, 0.2, 0.3])
        self.assertIsNotNone(model.options)
        assert model.options is not None
        self.assertTrue(model.options["normalize_embeddings"])
        self.assertFalse(model.options["show_progress_bar"])


if __name__ == "__main__":
    unittest.main()
