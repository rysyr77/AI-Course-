﻿$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
if (-not (Test-Path .\.venv\Scripts\python.exe)) {
  Write-Host "Project setup is incomplete. Run setup_windows.bat first." -ForegroundColor Red
  Read-Host "Press Enter to exit"
  exit 1
}
$admin = Read-Host "Enter admin dashboard password"
if ([string]::IsNullOrWhiteSpace($admin)) { $admin = "123456" }
$env:ADMIN_PASSWORD = $admin
$env:PORT = "7860"
Write-Host "Server: http://127.0.0.1:7860" -ForegroundColor Green
Write-Host "Admin: http://127.0.0.1:7860/admin" -ForegroundColor Green
Start-Process "http://127.0.0.1:7860"
& .\.venv\Scripts\python.exe -m backend.app