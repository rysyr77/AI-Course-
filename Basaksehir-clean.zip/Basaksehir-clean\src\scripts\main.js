const body = document.body;
const themeToggle = document.getElementById("themeToggle");
const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");
const chatWidget = document.getElementById("chat-widget");
const messageList = document.getElementById("messageList");
const chatForm = document.getElementById("chatForm");
const chatInput = document.getElementById("chatInput");
const sendButton = chatForm.querySelector(".send-button");
const quickPrompts = document.querySelectorAll(".quick-prompt");
const minimizeButton = document.getElementById("minimizeChat");
const closeButton = document.getElementById("closeChat");
const reopenButton = document.getElementById("reopenChat");
const clearButton = document.getElementById("clearChat");
const apiStatus = document.getElementById("apiStatus");

let currentRequestId = 0;
let currentRequestController = null;
let isSending = false;
const conversationHistory = [];

function setTheme(theme) {
  const isDark = theme === "dark";
  body.classList.toggle("dark-theme", isDark);
  themeToggle.setAttribute("aria-pressed", String(isDark));
  themeToggle.setAttribute("aria-label", isDark ? "تفعيل الوضع الفاتح" : "تفعيل الوضع الداكن");
}

try {
  setTheme(localStorage.getItem("campus-theme") || "light");
} catch {
  setTheme("light");
}

themeToggle.addEventListener("click", () => {
  const nextTheme = body.classList.contains("dark-theme") ? "light" : "dark";
  setTheme(nextTheme);
  try {
    localStorage.setItem("campus-theme", nextTheme);
  } catch {
    // Continue without persistence if browser storage is unavailable.
  }
});

menuToggle.addEventListener("click", () => {
  const isOpen = mainNav.classList.toggle("is-open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.setAttribute("aria-label", isOpen ? "إغلاق قائمة التنقل" : "فتح قائمة التنقل");
});

mainNav.addEventListener("click", (event) => {
  if (event.target.closest("a")) {
    mainNav.classList.remove("is-open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.setAttribute("aria-label", "فتح قائمة التنقل");
  }
});

function formatTime() {
  return new Intl.DateTimeFormat("ar", { hour: "numeric", minute: "2-digit" }).format(new Date());
}

function createAvatar(role) {
  const avatar = document.createElement("div");
  avatar.className = role === "assistant" ? "message-avatar" : "user-avatar";
  avatar.setAttribute("aria-hidden", "true");
  if (role === "assistant") {
    const image = document.createElement("img");
    image.src = "/public/assets/basaksehir-university-logo.jpg";
    image.alt = "";
    avatar.append(image);
  } else {
    avatar.textContent = "أ";
  }
  return avatar;
}

function appendMessage(role, text, sources = []) {
  const row = document.createElement("div");
  row.className = `message-row ${role === "assistant" ? "assistant-row" : "user-row"}`;

  const stack = document.createElement("div");
  stack.className = "message-stack";
  const bubble = document.createElement("div");
  bubble.className = `message-bubble ${role === "assistant" ? "assistant-bubble" : "user-bubble"}`;
  const paragraph = document.createElement("p");
  paragraph.textContent = text;
    paragraph.textContent = text;
  paragraph.style.whiteSpace = "pre-line"; // يحافظ على الأسطر الجديدة في الجواب
  bubble.append(paragraph);
  stack.append(bubble);

  const timestamp = document.createElement("time");
  timestamp.className = "message-time";
  timestamp.dateTime = new Date().toISOString();
  timestamp.textContent = formatTime();
  stack.append(timestamp);

  const avatar = createAvatar(role);
  if (role === "assistant") {
    row.append(avatar, stack);
  } else {
    row.append(stack, avatar);
  }
  messageList.append(row);
  messageList.scrollTop = messageList.scrollHeight;
}

function showTyping() {
  document.getElementById("typingIndicator")?.remove();
  const row = document.createElement("div");
  row.className = "typing-row";
  row.id = "typingIndicator";
  row.setAttribute("role", "status");
  row.setAttribute("aria-label", "المساعد يكتب إجابة");
  row.append(createAvatar("assistant"));
  const bubble = document.createElement("div");
  bubble.className = "typing-bubble";
  for (let index = 0; index < 3; index += 1) {
    bubble.append(document.createElement("span"));
  }
  row.append(bubble);
  messageList.append(row);
  messageList.scrollTop = messageList.scrollHeight;
}

function setSending(sending) {
  isSending = sending;
  chatInput.disabled = sending;
  sendButton.disabled = sending;
  quickPrompts.forEach((button) => {
    button.disabled = sending;
  });
}

async function sendMessage(text) {
  const message = text.trim();
  if (!message || isSending || chatWidget.classList.contains("is-closed")) return;
  if (message.length > 500) {
    appendMessage("assistant", "الحد الأقصى لطول السؤال هو 500 حرف.");
    return;
  }

  chatWidget.classList.remove("is-minimized");
  minimizeButton.setAttribute("aria-label", "تصغير المحادثة");
  appendMessage("user", message);
  chatInput.value = "";
  setSending(true);
  showTyping();

  const requestId = ++currentRequestId;
  const controller = new AbortController();
  currentRequestController = controller;
  const timeoutId = window.setTimeout(() => controller.abort(), 45_000);

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({ message, history: conversationHistory.slice(-6) }),
      signal: controller.signal,
    });
    const payload = await response.json().catch(() => null);
    if (requestId !== currentRequestId) return;

    if (!response.ok) {
      const serverMessage = typeof payload?.error === "string" ? payload.error : "تعذّر تنفيذ البحث.";
      throw new Error(serverMessage);
    }
    if (typeof payload?.answer !== "string") {
      throw new Error("وصل رد غير صالح من الخادم.");
    }

    document.getElementById("typingIndicator")?.remove();
    conversationHistory.push({ role: "user", content: message }, { role: "assistant", content: payload.answer });
    appendMessage("assistant", payload.answer, payload.sources || []);
  } catch (error) {
    if (requestId !== currentRequestId) return;
    document.getElementById("typingIndicator")?.remove();
    let messageToShow = error instanceof Error ? error.message : "حدث خطأ غير معروف.";
    if (error instanceof TypeError) {
      messageToShow = "تعذّر الاتصال بخادم Flask. تأكد من تشغيله على هذا العنوان.";
    } else if (error?.name === "AbortError") {
      messageToShow = "انتهت مهلة البحث. حاول مرة أخرى.";
    }
    appendMessage("assistant", messageToShow);
  } finally {
    window.clearTimeout(timeoutId);
    if (requestId === currentRequestId) {
      document.getElementById("typingIndicator")?.remove();
      currentRequestController = null;
      setSending(false);
      chatInput.focus({ preventScroll: true });
    }
  }
}

chatForm.addEventListener("submit", (event) => {
  event.preventDefault();
  void sendMessage(chatInput.value);
});

quickPrompts.forEach((button) => {
  button.addEventListener("click", () => {
    void sendMessage(button.dataset.question || "");
  });
});

minimizeButton.addEventListener("click", () => {
  const isMinimized = chatWidget.classList.toggle("is-minimized");
  minimizeButton.setAttribute("aria-label", isMinimized ? "توسيع المحادثة" : "تصغير المحادثة");
});

closeButton.addEventListener("click", () => {
  chatWidget.classList.add("is-closed");
  reopenButton.hidden = false;
  reopenButton.focus();
});

reopenButton.addEventListener("click", () => {
  chatWidget.classList.remove("is-closed", "is-minimized");
  reopenButton.hidden = true;
  chatWidget.scrollIntoView({ behavior: "smooth", block: "center" });
  chatInput.focus({ preventScroll: true });
});

clearButton.addEventListener("click", () => {
  currentRequestId += 1;
  currentRequestController?.abort();
  currentRequestController = null;
  setSending(false);
  messageList.replaceChildren();
  conversationHistory.length = 0;
  appendMessage("assistant", "تم مسح المحادثة. اسأل عن محتوى المادة.");
  chatInput.value = "";
  chatInput.focus();
});

async function updateBackendStatus() {
  try {
    const response = await fetch("/api/health", { headers: { Accept: "application/json" }, cache: "no-store" });
    const health = await response.json();
    const ready = response.ok && health.ready === true;
    apiStatus.classList.toggle("is-offline", !ready);
    apiStatus.title = ready ? "قاعدة المعرفة جاهزة" : "شغّل بناء قاعدة المعرفة أولاً";
    apiStatus.setAttribute("aria-label", apiStatus.title);
  } catch {
    apiStatus.classList.add("is-offline");
    apiStatus.title = "خادم Flask غير متصل";
    apiStatus.setAttribute("aria-label", apiStatus.title);
  }
}

void updateBackendStatus();
document.getElementById("currentYear").textContent = String(new Date().getFullYear());
