# AI Course Assistant — جامعة Başakşehir

نسخة مطوّرة من واجهة مساعد الجامعة الحالية إلى نظام RAG حقيقي باستخدام Flask وChromaDB وSentence Transformers وGemini. يدعم رفع ملفات PDF النصية وTXT وMarkdown وJSON، واعتماد المصادر من لوحة إدارة عربية، وإظهار المصادر أسفل إجابات الطلاب.

ابدأ من [دليل التشغيل العربي](README_AR.md). للتشغيل السريع:

```bash
python -m pip install -r requirements.txt
cp .env.example .env
python -m backend.make_embeddings --overwrite
python -m backend.app
```

لا تضع `GEMINI_API_KEY` أو `ADMIN_PASSWORD` داخل Git. في الإنتاج استخدم Secrets، وراجع ملاحظة التخزين المؤقت في دليل Hugging Face.
