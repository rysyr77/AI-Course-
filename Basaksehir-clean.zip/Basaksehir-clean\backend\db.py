"""Tiny SQLite repository for admin metadata and unanswered questions."""
from __future__ import annotations
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from .config import SQLITE_PATH

def connect() -> sqlite3.Connection:
    SQLITE_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(SQLITE_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db() -> None:
    with connect() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS documents (id TEXT PRIMARY KEY, filename TEXT NOT NULL, source_name TEXT, source_type TEXT, section TEXT, academic_year TEXT, semester TEXT, updated_at TEXT, status TEXT NOT NULL, chunk_count INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS unanswered (id INTEGER PRIMARY KEY AUTOINCREMENT, question TEXT NOT NULL, created_at TEXT NOT NULL);
        ''')

def now() -> str: return datetime.now(timezone.utc).isoformat()
def list_documents():
    init_db()
    with connect() as db: return [dict(r) for r in db.execute('SELECT * FROM documents ORDER BY updated_at DESC')]
def save_document(row: dict) -> None:
    init_db()
    with connect() as db:
        db.execute('''INSERT INTO documents(id,filename,source_name,source_type,section,academic_year,semester,updated_at,status,chunk_count) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET filename=excluded.filename,source_name=excluded.source_name,source_type=excluded.source_type,section=excluded.section,academic_year=excluded.academic_year,semester=excluded.semester,updated_at=excluded.updated_at,status=excluded.status,chunk_count=excluded.chunk_count''', tuple(row.get(k) for k in ('id','filename','source_name','source_type','section','academic_year','semester','updated_at','status','chunk_count')))
def set_status(doc_id: str, status: str) -> None:
    init_db()
    with connect() as db: db.execute('UPDATE documents SET status=?, updated_at=? WHERE id=?', (status, now(), doc_id))
def delete_document(doc_id: str) -> None:
    init_db()
    with connect() as db: db.execute('DELETE FROM documents WHERE id=?', (doc_id,))
def log_unanswered(question: str) -> None:
    init_db()
    with connect() as db: db.execute('INSERT INTO unanswered(question,created_at) VALUES(?,?)', (question, now()))
def list_unanswered():
    init_db()
    with connect() as db: return [dict(r) for r in db.execute('SELECT * FROM unanswered ORDER BY created_at DESC LIMIT 100')]
