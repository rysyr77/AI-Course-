# دليل مشروع AI Course Assistant

المشروع يحتفظ بواجهة جامعة Başakşehir الموجودة، ويضيف لها خدمة Flask وبحثاً دلالياً محلياً. لا يحتاج مفتاح API ولا يرسل أسئلة الطلاب إلى خدمة ذكاء اصطناعي مدفوعة. يُنزّل نموذج embeddings أول مرة ويُشغّل محلياً على CPU.

## 1. الواجهة الأمامية

الملف `index.html` هو الصفحة الحالية بهوية الجامعة وشعارها وخلفية المبنى. تحتفظ ملفات `src/styles/tailwind.css` و`src/styles/site.css` بالتصميم، ويعالج `src/scripts/main.js` الأحداث والرسائل. بدلاً من الإجابات التجريبية الثابتة، يرسل السكربت السؤال إلى `/api/chat` على نفس الخادم باستخدام Fetch API. تبقى الأسئلة السريعة، مؤشر الكتابة، التمرير التلقائي، الوضع الداكن، مسح المحادثة وإغلاقها. يخدم Flask هذه الصفحة والصور وملفات CSS وJavaScript من نفس المصدر، فلا حاجة إلى إعداد CORS.

## 2. تجهيز قاعدة المعرفة والمتجهات

يحتوي `backend/data/knowledge_base.json` على عشرة أمثلة تعليمية عن الذكاء الاصطناعي وRAG، بينها صيغتان بديلتان لسؤال RAG لتوضيح أثر تغطية صيغ الطلاب في الاسترجاع. استبدلها بمحتوى مادتك مع المحافظة على شكل العنصر التالي:

```json
{
  "id": "lecture-01-q1",
  "category": "المحاضرة الأولى",
  "question": "ما تعريف التعلم الآلي؟",
  "answer": "الإجابة المعتمدة بحسب محتوى المحاضرة...",
  "keywords": ["Machine Learning", "ML", "التعلم الآلي"]
}
```

كل عنصر يحتاج `id` فريداً و`question` و`answer` غير فارغين؛ `keywords` و`category` اختياريان. كل سؤال في JSON يمثّل وحدة استرجاع مستقلة. أضف صيغ السؤال البديلة كسجلات إضافية بمعرّفات مختلفة وبالإجابة نفسها، حتى يتعامل النظام مع طرق الصياغة المتوقعة.

يقرأ `backend/make_embeddings.py` الملف ويتحقق من سلامته، ثم يستخدم نموذج `sentence-transformers/all-MiniLM-L6-v2` لتوليد embeddings على الجهاز. يخزن السؤال ومفاتيحه والإجابة في مجموعة `course_qa` داخل `backend/vector_store/`، مع ضبط مقياس Chroma على `cosine`. يبقى هذا المخزن محلياً ولا يُضمّن في ZIP؛ يُنشأ من ملف JSON عند الإعداد.

## 3. واجهة Flask والبحث

يوفر `backend/app.py` المسارين `POST /api/chat` و`GET /api/health`. مثال الطلب:

```json
{"message": "ما معنى RAG؟"}
```

تعيد الواجهة `ok` و`answer` و`matched` و`source` و`similarity`. يفحص المحرك أولاً وجود سؤال مخزن مطابق، ثم ينفذ البحث المتجهي؛ وإذا كانت أقرب مسافة cosine أكبر من `RAG_MAX_DISTANCE` (القيمة الافتراضية `0.45`) يعيد رسالة تفيد بأنه لم يجد تطابقاً، بدلاً من تخمين إجابة. غيّر العتبة بعد اختبار أمثلة حقيقية؛ المسافة الأقل تعني تشابهاً أعلى. ينفذ `backend/rag_engine.py` تضمين السؤال مرة واحدة لكل طلب واسترجاع أقرب جواب محفوظ.

هذا تنفيذ مجاني للاسترجاع وإعادة الجواب الموافق من قاعدة المعرفة. لا يوجد نموذج توليدي يكتب إجابات جديدة؛ إضافة التوليد ستتطلب تشغيل نموذج لغة محلي منفصل أو خدمة أخرى.

## 4. التثبيت والتشغيل والاختبار

استخدم Python 3.11 أو 3.12. من مجلد المشروع أنشئ بيئة مستقلة وثبّت الاعتماديات:

```bash
python -m venv .venv
```

على Linux أو macOS فعّل البيئة وثبّت الحزم:

```bash
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

في Windows PowerShell فعّلها هكذا، ثم نفّذ أمر تثبيت المتطلبات:

```powershell
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

لتثبيت نسخة CPU فقط من PyTorch اختيارياً، نفّذ هذا الأمر قبل تثبيت `requirements.txt` على نظام يدعمه:

```bash
python -m pip install torch --index-url https://download.pytorch.org/whl/cpu
python -m pip install -r requirements.txt
```

لا تحتاج إلى GPU. لا توجد رسوم API، لكن تنزيل المكتبات والنموذج أول مرة يحتاج اتصالاً بالإنترنت ومساحة قرص ووقتاً.

ابن قاعدة المتجهات من جذر المشروع:

```bash
python -m backend.make_embeddings
```

بعد تعديل ملف JSON أعد البناء باستبدال المجموعة المحلية صراحةً:

```bash
python -m backend.make_embeddings --overwrite
```

هذا الخيار يحذف مجموعة `course_qa` القديمة من قاعدة Chroma المحلية ويعيد إنشاءها؛ لا تستخدمه إذا أردت الاحتفاظ بالفهرس القديم. ثم شغّل الموقع والـAPI:

```bash
python -m backend.app
```

افتح `http://127.0.0.1:3000`. لا تفتح `index.html` كملف مباشر؛ يجب تشغيل Flask حتى يعمل المسار `/api/chat`. يبقى الخادم محلياً على `127.0.0.1` افتراضياً، و`debug` معطل. في بيئة معاينة حاوية فقط يمكن تحديد `HOST=0.0.0.0` و`PORT=3000`؛ لا تعرضه على شبكة عامة دون إعداد أمني مناسب.

افحص جاهزية الخدمة:

```bash
curl http://127.0.0.1:3000/api/health
```

واختبر طلباً عربياً:

```bash
curl -X POST http://127.0.0.1:3000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"ما معنى RAG؟"}'
```

في PowerShell يمكن استخدام:

```powershell
Invoke-RestMethod -Uri http://127.0.0.1:3000/api/chat -Method Post -ContentType 'application/json' -Body '{"message":"ما معنى RAG؟"}'
```

تشغّل اختبارات API بعميل Flask تجريبي، فلا تحتاج إلى تنزيل النموذج أو بناء Chroma:

```bash
python -m unittest backend.tests.test_api -v
```

إذا ظهر خطأ `503`، فتأكد أنك شغلت `python -m backend.make_embeddings` من جذر المشروع. إذا ظهرت `400`، افحص أن الطلب JSON ويحتوي `message` نصياً لا يتجاوز 500 حرف. وإذا ظهر `500`، اقرأ سجل Flask في الطرفية؛ يخفي الرد تفاصيل الاستثناء عن المتصفح. إذا تعذّر اتصال الواجهة، تأكد أن Flask ما زال يعمل وأنك فتحت الموقع من عنوانه المحلي لا من ملف HTML.

## ملاحظة مهمة عن اللغة

استخدمنا `all-MiniLM-L6-v2` كما طلبت. هذا النموذج أصغر وموجّه أساساً للنص الإنجليزي؛ قد تكون جودة التشابه أقل في أسئلة عربية خالصة. عند الاعتماد على مادة عربية، يمكن تجربة `intfloat/multilingual-e5-small` من دون تغيير الكود، لأنه يدعم لغات متعددة، مع إعادة بناء الفهرس بعد تبديل النموذج. يدعم الكود بادئتي `query:` و`passage:` المطلوبتين لهذا النموذج البديل. عيّن متغير البيئة `EMBEDDING_MODEL` إلى اسمه نفسه قبل تشغيل سكربت الفهرسة والخادم، وإلا ستنتج متجهات الاستعلام والفهرس من نموذجين مختلفين.

## بنية المشروع

```text
backend/
  app.py                       Flask وAPI وتقديم الواجهة
  config.py                    إعدادات النموذج والمسارات والعتبة
  rag_engine.py                embeddings والبحث الدلالي
  make_embeddings.py           فحص JSON وإنشاء مجموعة Chroma
  data/knowledge_base.json     أسئلة وأجوبة تجريبية للمادة
  tests/test_api.py            اختبارات Flask بعميل مزيف
  vector_store/                يُنشأ محلياً عند بناء embeddings
index.html                     واجهة جامعة باشاك شهير الحالية
src/scripts/main.js            أحداث الواجهة وFetch API
src/styles/                    CSS الحالي والتنسيقات
public/assets/                 صور الجامعة وCSS المجمّع
requirements.txt               الاعتماديات المفتوحة المصدر
```
