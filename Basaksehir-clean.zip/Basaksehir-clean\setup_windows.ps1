﻿$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
Write-Host "=== AI Course Assistant - Windows setup ===" -ForegroundColor Cyan

function Get-Python312 {
  try { & py -3.12 --version 2>$null; if ($LASTEXITCODE -eq 0) { return "py -3.12" } } catch {}
  try {
    $v = & python --version 2>$null
    if ($v -match "Python 3\.12") { return "python" }
  } catch {}
  return $null
}

$pythonCommand = Get-Python312
if (-not $pythonCommand) {
  Write-Host "Python 3.12 غير موجود. سأحاول تثبيته عبر Windows Package Manager (winget)..." -ForegroundColor Yellow
  try {
    winget install --id Python.Python.3.12 --exact --scope user --accept-package-agreements --accept-source-agreements
  } catch {
    Write-Host "تعذر تثبيت Python تلقائيًا. ثبّت Python 3.12 من:" -ForegroundColor Red
    Write-Host "https://www.python.org/downloads/release/python-31210/"
    Write-Host "وفعّل خيار Add python.exe to PATH، ثم شغّل هذا الملف مرة أخرى."
    Read-Host "اضغط Enter للخروج"
    exit 1
  }
  $pythonCommand = Get-Python312
}
if (-not $pythonCommand) {
  Write-Host "تم تثبيت Python لكن PowerShell لم يحدّث PATH بعد." -ForegroundColor Yellow
  Write-Host "أغلق PowerShell وافتحه من جديد، ثم شغّل setup_windows.ps1 مرة أخرى."
  Read-Host "اضغط Enter للخروج"
  exit 1
}

if (Test-Path .venv) { Remove-Item -Recurse -Force .venv }
if ($pythonCommand -eq "py -3.12") { & py -3.12 -m venv .venv } else { & python -m venv .venv }
& .\.venv\Scripts\python.exe -m pip install --upgrade pip
& .\.venv\Scripts\python.exe -m pip install -r requirements-windows.txt

if (-not (Test-Path .env)) { Copy-Item .env.example .env }
Write-Host "تم تثبيت المكتبات بنجاح." -ForegroundColor Green
Write-Host "سيتم الآن بناء فهرس قاعدة المعرفة التجريبية، وقد يستغرق تنزيل النموذج دقائق..." -ForegroundColor Yellow
& .\.venv\Scripts\python.exe -m backend.make_embeddings --overwrite

Write-Host "اكتمل الإعداد. شغّل start_windows.ps1 لتشغيل الموقع." -ForegroundColor Green
Read-Host "اضغط Enter للخروج"
