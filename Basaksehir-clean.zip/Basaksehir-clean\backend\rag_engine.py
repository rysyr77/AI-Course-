"""بحث دلالي متعدد اللغات ثم جواب مبني على قاعدة الجامعة (مع إعادة صياغة السؤال)."""
from __future__ import annotations
import re, unicodedata
from typing import Any
from .config import COLLECTION_NAME, DOCUMENT_COLLECTION_NAME, EMBEDDING_DEVICE, EMBEDDING_MODEL, NO_MATCH_ANSWER, VECTOR_STORE_DIR
from .llm import generate_answer, generate_general_answer, rewrite_query, NOT_IN_KB


class KnowledgeBaseNotReadyError(RuntimeError): pass
class RAGDependenciesMissingError(RuntimeError): pass


POOL_SIZE = 8  # عدد العناصر اللي نعطيها للنموذج ليحكم عليها


def prepare_text(text: str, *, task: str, model_name: str = EMBEDDING_MODEL) -> str:
    if model_name.casefold().startswith('intfloat/multilingual-e5'):
        return f"{'query' if task == 'query' else 'passage'}: {text}"
    return text

def encode_texts(model: Any, texts: list[str], *, task: str) -> Any:
    return model.encode([prepare_text(t, task=task) for t in texts], batch_size=64, convert_to_numpy=True, normalize_embeddings=True, show_progress_bar=(task == 'passage'))

def normalize_question(text: str) -> str:
    text = unicodedata.normalize('NFKC', text).casefold()
    text = ''.join(c for c in text if unicodedata.category(c) != 'Mn')
    return ' '.join(re.sub(r'[^\w\s]', ' ', text, flags=re.UNICODE).split())


# ===== ردود جاهزة للتحيات والأسئلة التعريفية (لا تحتاج بحثاً ولا نموذجاً) =====
_HELP_HINT = "اسألني عن التخصصات، الرسوم، المواد والدكاترة، أو تعليمات الامتحانات والمخالفات."

# كلمات تدل على سؤال عن المطورين (بحث بالاحتواء ليشمل صيغاً كثيرة)
DEV_KEYWORDS = ("عملك", "صنعك", "برمجك", "طورك", "صممك", "سواك", "مطورين", "مطوريك",
                "مبرمجين", "who made", "who created", "who developed", "who built")
DEV_REPLY = "طوّرني فريق من ثلاثة مطورين: أحمد القيم، أحمد الخالد، وخالد دامور. 💻"

# كل عنصر: (مجموعة عبارات مطابقة تماماً، الرد الجاهز)
SMALL_TALK = [
    ({"مرحبا", "مرحبا بك", "هلا", "اهلا", "أهلا", "اهلين", "أهلين", "هاي", "سلام",
      "السلام عليكم", "صباح الخير", "مساء الخير", "hello", "hi"},
     f"أهلاً وسهلاً! 👋 {_HELP_HINT}"),
    ({"من انت", "من أنت", "مين انت", "مين أنت", "انت مين", "أنت مين", "شو انت",
      "ما اسمك", "شو اسمك", "who are you", "what are you"},
     f"أنا المساعد الذكي لجامعة باشاك شهير، أجاوب من الملفات الجامعية المعتمدة فقط. {_HELP_HINT}"),
    ({"شكرا", "شكرا لك", "شكراً", "شكراً لك", "يعطيك العافية", "يسلمو", "thanks", "thank you"},
     "العفو! إذا عندك سؤال ثاني أنا حاضر. 😊"),
    ({"كيفك", "كيف حالك", "شلونك", "شو الاخبار", "how are you"},
     f"تمام الحمدلله، شكراً لسؤالك! {_HELP_HINT}"),
]

def small_talk_reply(text: str) -> str | None:
    """يرجع رداً جاهزاً إذا كان السؤال تحية أو تعريفاً أو عن المطورين، وإلا None."""
    q = normalize_question(text)
    if any(k in q for k in DEV_KEYWORDS):
        return DEV_REPLY
    for phrases, reply in SMALL_TALK:
        if q in {normalize_question(p) for p in phrases}:
            return reply
    return None


class RAGAssistant:
    def __init__(self) -> None:
        if not VECTOR_STORE_DIR.is_dir(): raise KnowledgeBaseNotReadyError('Vector store is missing')
        try:
            import chromadb
            from sentence_transformers import SentenceTransformer
        except ImportError as exc: raise RAGDependenciesMissingError('Install requirements.txt') from exc
        try:
            client = chromadb.PersistentClient(path=str(VECTOR_STORE_DIR))
            self.client = client  # نحتفظ به لإعادة جلب مجموعة الملفات لاحقاً
            try:
                self.collection = client.get_collection(name=COLLECTION_NAME)
            except Exception:
                self.collection = client.create_collection(name=COLLECTION_NAME, metadata={'hnsw:space': 'cosine'})
        except Exception as exc: raise KnowledgeBaseNotReadyError('Chroma collection is missing') from exc
        try: self.documents = client.get_collection(name=DOCUMENT_COLLECTION_NAME)
        except Exception: self.documents = None
        if self.collection.count() == 0 and (self.documents is None or self.documents.count() == 0): raise KnowledgeBaseNotReadyError('No indexed content')
        self.model_name, self.model = EMBEDDING_MODEL, SentenceTransformer(EMBEDDING_MODEL, device=EMBEDDING_DEVICE)

    def _legacy_candidates(self, question: str, vector: list[float]) -> list[dict[str, Any]]:
        """أقرب أسئلة/أجوبة من قاعدة المعرفة. السياق يحتوي السؤال والجواب معاً."""
        if not self.collection or not self.collection.count(): return []
        result = self.collection.query(query_embeddings=[vector], n_results=min(5, self.collection.count()), include=['metadatas', 'distances'])
        output = []
        for meta, distance in zip((result.get('metadatas') or [[]])[0], (result.get('distances') or [[]])[0]):
            meta = meta or {}
            q_text, a_text = str(meta.get('question', '')), str(meta.get('answer', ''))
            output.append({'text': f"السؤال: {q_text}\nالجواب: {a_text}", 'filename': 'قاعدة معرفة الجامعة', 'source_name': 'قاعدة المعرفة', 'source_type': 'official', 'page': '', 'updated_at': '', 'similarity': round(1 - float(distance), 4), 'distance': float(distance), 'question': q_text})
        return output

    def answer(self, question: str, history: list[dict[str, str]] | None = None) -> dict[str, Any]:
        # 1) التحيات والأسئلة التعريفية: رد جاهز بدون بحث
        reply = small_talk_reply(question)
        if reply:
            return {'matched': True, 'answer': reply, 'source': None, 'sources': [], 'updated_at': None, 'similarity': 1.0}

        # 2) تطابق حرفي مع سؤال محفوظ بالقاعدة
        exact_rows = self.collection.get(where={'question': question}, include=['metadatas'])
        exact = next((row for row in (exact_rows.get('metadatas') or []) if row), None)
        if exact and exact.get('answer'):
            return {'matched': True, 'answer': str(exact['answer']), 'source': str(exact.get('question') or ''), 'sources': [], 'updated_at': None, 'similarity': 1.0}

        # 3) نعيد جلب مجموعة الملفات حتى تظهر الملفات المرفوعة حديثاً بدون ريستارت
        client = getattr(self, 'client', None)
        if client is not None:
            try: self.documents = client.get_collection(name=DOCUMENT_COLLECTION_NAME)
            except Exception: pass

        # 4) إعادة صياغة السؤال (ربط بالمحادثة + مرادفات) ثم البحث بكل الصيغ
        queries = rewrite_query(question, history)
        vectors = encode_texts(self.model, queries, task='query')
        candidates = []
        for vec in vectors:
            vector = vec.tolist()
            if getattr(self, 'documents', None) and self.documents.count():
                result = self.documents.query(query_embeddings=[vector], n_results=min(8, self.documents.count()), where={'approved': 'true'}, include=['documents', 'metadatas', 'distances'])
                for text, meta, distance in zip((result.get('documents') or [[]])[0], (result.get('metadatas') or [[]])[0], (result.get('distances') or [[]])[0]):
                    candidates.append({'text': text, **(meta or {}), 'similarity': round(1 - float(distance), 4), 'distance': float(distance)})
            candidates += self._legacy_candidates(question, vector)

        # 5) ندمج المكرر (أقرب مسافة لكل نص) ونأخذ أفضل POOL_SIZE
        best = {}
        for c in candidates:
            if not c.get('text'):
                continue
            if c['text'] not in best or c['distance'] < best[c['text']]['distance']:
                best[c['text']] = c
        pool = sorted(best.values(), key=lambda c: c['distance'])[:POOL_SIZE]
        best_sim = pool[0].get('similarity') if pool else None

        # 6) النموذج هو الحكم: إذا الجواب موجود بالسياق يجاوب منه حصراً
        if pool:
            answer = generate_answer(question, pool, history)
            if NOT_IN_KB not in answer:
                # شبكة أمان: نحذف أي [المصدر N] يكتبه النموذج داخل النص
                answer = re.sub(r'\s*\[(?:المصدر\s*)?\d+(?:\s*[,،]\s*\d+)*\]', '', answer).strip()
                return {'matched': True, 'answer': answer, 'sources': [], 'updated_at': None, 'similarity': best_sim}

        # 7) خارج القاعدة: جواب عام من النموذج (مع حماية أسئلة الجامعة من التخمين)
        try:
            general = generate_general_answer(question, history)
        except Exception:
            general = None
        if general:
            return {'matched': False, 'answer': general, 'source': None, 'sources': [], 'updated_at': None, 'similarity': best_sim}
        return self._no_match(similarity=best_sim)

    @staticmethod
    def _no_match(*, similarity: float | None = None) -> dict[str, Any]:
        return {'matched': False, 'answer': NO_MATCH_ANSWER, 'source': None, 'sources': [], 'updated_at': None, 'similarity': similarity}