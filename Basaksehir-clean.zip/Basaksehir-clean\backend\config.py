"""Central configuration loaded from environment variables."""
from __future__ import annotations
import os
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
from dotenv import load_dotenv
load_dotenv(PROJECT_ROOT / ".env")
BACKEND_DIR = Path(__file__).resolve().parent
DATA_PATH = BACKEND_DIR / "data" / "knowledge_base.json"
UPLOAD_DIR = BACKEND_DIR / "data" / "uploads"
VECTOR_STORE_DIR = BACKEND_DIR / "vector_store"
SQLITE_PATH = BACKEND_DIR / "data" / "assistant.sqlite3"
COLLECTION_NAME = os.getenv("CHROMA_COLLECTION", "course_qa")
DOCUMENT_COLLECTION_NAME = os.getenv("CHROMA_DOCUMENT_COLLECTION", "university_documents")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "intfloat/multilingual-e5-small")
EMBEDDING_DEVICE = os.getenv("EMBEDDING_DEVICE", "cpu")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "").strip()
MAX_QUESTION_LENGTH = int(os.getenv("MAX_QUESTION_LENGTH", "500"))
MAX_UPLOAD_SIZE = int(os.getenv("MAX_UPLOAD_SIZE", str(25 * 1024 * 1024)))
ALLOWED_EXTENSIONS = {".pdf", ".txt", ".md", ".markdown", ".json"}
try:
    RAG_MAX_DISTANCE = float(os.getenv("RAG_MAX_DISTANCE", "0.45"))
except ValueError as exc:
    raise RuntimeError("RAG_MAX_DISTANCE must be a number between 0 and 2") from exc
if not 0 <= RAG_MAX_DISTANCE <= 2:
    raise RuntimeError("RAG_MAX_DISTANCE must be between 0 and 2")
NO_MATCH_ANSWER = "لم أجد إجابة موثوقة في الملفات الجامعية المعتمدة. جرّب صياغة السؤال بطريقة أخرى أو اطلب من المسؤول إضافة المصدر المناسب."
KNOWLEDGE_BASE_NOT_READY = "قاعدة المعرفة غير جاهزة. أضف ملفًا معتمدًا أو شغّل بناء الفهرس من لوحة الإدارة."
