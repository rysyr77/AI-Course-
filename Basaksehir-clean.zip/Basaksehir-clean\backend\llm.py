"""محوّل موحّد لمزوّدي النماذج (Groq / Ollama / Gemini) مع تجربة تلقائية للبدائل،
وإعادة صياغة الأسئلة قبل البحث، والجواب من قاعدة الجامعة أو من المعرفة العامة."""
from __future__ import annotations
import logging
import os
import re
from typing import Any

import requests

from . import config  # استيراده يضمن تحميل ملف .env قبل قراءة المتغيرات


class LLMNotConfiguredError(RuntimeError): pass
class LLMUnavailableError(RuntimeError): pass


# علامة يعيدها النموذج حين لا يجد الجواب ضمن السياق المعطى (قاعدة الجامعة)
NOT_IN_KB = "__NOT_IN_KB__"
# علامة يعيدها النموذج حين يكون السؤال عن الجامعة نفسها ولا توجد له مصادر
NO_UNI_INFO = "__NO_UNI_INFO__"


def _history_text(history: list[dict[str, str]] | None) -> str:
    """آخر 4 رسائل من المحادثة كنص."""
    if not history:
        return ""
    return "\n".join(f"{m.get('role', 'user')}: {m.get('content', '')}" for m in history[-4:])


def _build_prompt(question: str, contexts: list[dict[str, Any]], history: list[dict[str, str]] | None) -> str:
    """طلب الجواب المقيّد بقاعدة معرفة الجامعة فقط."""
    sources = [f"[{i}] {item.get('text', '')}" for i, item in enumerate(contexts, 1)]
    return f"""أنت مساعد جامعي. أجب بالعربية أو الإنجليزية حسب لغة السؤال.
السياق فيه أسئلة وأجوبة من قاعدة معرفة الجامعة. افهم قصد الطالب حتى لو استخدم كلمات مختلفة (مثل: غش = نقل = مخالفة امتحانية، قوانين = آداب = تعليمات).
إذا وجدت الجواب في السياق فأجب منه حصراً، ولا تضف أي معلومة من خارجه.
إذا لم يحتوِ السياق على جواب لسؤال الطالب، فاكتب فقط هذه العلامة بدون أي كلمة أخرى: {NOT_IN_KB}
لا تذكر أرقام المصادر داخل الجواب لأنها تُعرض للطالب تحت الجواب. لا تخمّن ولا تخلط بين مسودة ومصدر معتمد.
اكتب الجواب كنص عادي بدون جداول وبدون رموز Markdown مثل | و ** و #. وإذا ذكرت أكثر من عنصر فاكتب كل عنصر في سطر مستقل يبدأ بـ "-".
السياق:
{chr(10).join(sources)}
سجل المحادثة المختصر:
{_history_text(history)}
سؤال الطالب: {question}
"""


def _build_general_prompt(question: str, history: list[dict[str, str]] | None) -> str:
    """طلب الجواب العام من معرفة النموذج، مع حماية للأسئلة الخاصة بالجامعة."""
    return f"""أنت مساعد ذكي في موقع جامعة باشاك شهير. السؤال التالي لا يوجد له جواب في ملفات الجامعة.
- إذا كان السؤال عن الجامعة نفسها (الرسوم، الدكاترة، المواد، المواعيد، التعليمات، الامتحانات، العقوبات، التسجيل...) فلا تجب ولا تخمّن، واكتب فقط هذه العلامة: {NO_UNI_INFO}
- وإلا فأجب من معرفتك العامة بإيجاز ودقة (حتى 6 أسطر)، بنفس لغة السؤال (والعامية الشامية تُجاب بالعربية المبسّطة).
- إذا لم تكن متأكداً من المعلومة فاعترف بذلك بدل أن تخترع.
- اكتب نصاً عادياً بدون جداول وبدون رموز Markdown مثل | و ** و #.
سجل المحادثة المختصر:
{_history_text(history)}
السؤال: {question}
"""


def _gemini(prompt: str) -> str:
    key = os.getenv("GEMINI_API_KEY", "").strip()
    if not key:
        raise LLMNotConfiguredError("GEMINI_API_KEY غير موجود")
    from google import genai
    client = genai.Client(api_key=key)
    resp = client.models.generate_content(model=os.getenv("GEMINI_MODEL", "gemini-3.8-flash"), contents=prompt)
    return resp.text or ""


def _groq(prompt: str) -> str:
    key = os.getenv("GROQ_API_KEY", "").strip()
    if not key:
        raise LLMNotConfiguredError("GROQ_API_KEY غير موجود")
    r = requests.post(
        "https://api.groq.com/openai/v1/chat/completions",
        headers={"Authorization": f"Bearer {key}"},
        json={
            "model": os.getenv("GROQ_MODEL", "openai/gpt-oss-120b"),
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.2,
        },
        timeout=60,
    )
    # نعرض نص الخطأ الكامل من Groq لتسهيل التشخيص
    if not r.ok:
        raise RuntimeError(f"Groq {r.status_code}: {r.text[:500]}")
    return r.json()["choices"][0]["message"]["content"]


def _ollama(prompt: str) -> str:
    r = requests.post(
        os.getenv("OLLAMA_URL", "http://127.0.0.1:11434") + "/api/chat",
        json={
            "model": os.getenv("OLLAMA_MODEL", "qwen2.5:7b"),
            "messages": [{"role": "user", "content": prompt}],
            "stream": False,
            "options": {"temperature": 0.2},
        },
        timeout=180,
    )
    r.raise_for_status()
    return r.json()["message"]["content"]


_PROVIDERS = {"gemini": _gemini, "groq": _groq, "ollama": _ollama}


def _run_providers(prompt: str) -> str:
    """يجرّب المزوّدين بالترتيب المحدد في LLM_PROVIDER ويرجع أول جواب ناجح."""
    order = [p.strip() for p in os.getenv("LLM_PROVIDER", "groq,ollama,gemini").split(",") if p.strip()]
    errors: list[str] = []
    not_configured = 0
    for name in order:
        fn = _PROVIDERS.get(name)
        if not fn:
            continue
        try:
            text = (fn(prompt) or "").strip()
            if text:
                return text
            errors.append(f"{name}: رد فارغ")
        except LLMNotConfiguredError as exc:
            not_configured += 1
            errors.append(f"{name}: {exc}")
        except Exception as exc:  # نسجّل الخطأ ونجرّب المزوّد التالي
            logging.exception("LLM provider failed: %s", name)
            errors.append(f"{name}: {type(exc).__name__}: {exc}")
    if order and not_configured == len(order):
        raise LLMNotConfiguredError("; ".join(errors))
    raise LLMUnavailableError("جميع المزوّدين فشلوا -> " + " | ".join(errors))


def generate_answer(question: str, contexts: list[dict[str, Any]], history: list[dict[str, str]] | None = None) -> str:
    """جواب مبني على قاعدة الجامعة فقط. قد يرجع العلامة NOT_IN_KB إذا لم يجد الجواب."""
    if not contexts:
        raise LLMUnavailableError("No trusted context was retrieved")
    return _run_providers(_build_prompt(question, contexts, history))


def generate_general_answer(question: str, history: list[dict[str, str]] | None = None) -> str | None:
    """جواب عام من معرفة النموذج. يرجع None إذا كان السؤال عن الجامعة ولا توجد مصادر."""
    text = _run_providers(_build_general_prompt(question, history))
    if NO_UNI_INFO in text:
        return None
    return text


def rewrite_query(question: str, history: list[dict[str, str]] | None = None) -> list[str]:
    """يجهّز السؤال للبحث: يربطه بالمحادثة ويولّد صيغاً بديلة بمرادفات. يرجع السؤال الأصلي أولاً."""
    prompt = f"""مهمتك تجهيز سؤال للبحث في قاعدة معرفة جامعية، وليس الإجابة عنه.
اعتماداً على سجل المحادثة والسؤال الأخير، اكتب 3 صيغ للسؤال الأخير، كل صيغة بسطر مستقل:
- الصيغة 1: سؤال كامل ومستقل بالفصحى (أكمل أي إحالة مثل "وهي" و"كمان" بالرجوع للسجل).
- الصيغة 2: نفس المعنى بمرادفات (مثلاً: غش = نقل = مخالفة امتحانية، قوانين = آداب = تعليمات = شروط، رسوم = تكلفة = سعر).
- الصيغة 3: كلمات مفتاحية فقط.
لا تجب عن السؤال ولا تضف شرحاً.
سجل المحادثة:
{_history_text(history)}
السؤال الأخير: {question}
"""
    try:
        text = _run_providers(prompt)
    except Exception:
        return [question]  # إذا فشلت الإعادة نكمل بالسؤال الأصلي
    variants = []
    for line in text.splitlines():
        line = re.sub(r'^[\s\-\*\d\.\)]+', '', line)
        line = re.sub(r'^الصيغة\s*\d+\s*[:：]\s*', '', line).strip()
        if line and len(line) < 300 and line != question:
            variants.append(line)
    return [question] + variants[:3]