"""Fast API tests with a fake retrieval engine; no model download is needed."""

import unittest

from backend.app import create_app


class FakeAssistant:
    def answer(self, question: str) -> dict:
        return {
            "matched": True,
            "answer": f"إجابة تجريبية عن: {question}",
            "source": "ما المقصود بالذكاء الاصطناعي؟",
            "similarity": 0.91,
        }


class FailingAssistant:
    def answer(self, _question: str) -> dict:
        raise RuntimeError("private internal detail")


class ChatApiTests(unittest.TestCase):
    def setUp(self) -> None:
        self.client = create_app(FakeAssistant()).test_client()

    def test_chat_returns_json_answer(self) -> None:
        response = self.client.post("/api/chat", json={"message": "ما هو AI؟"})
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.get_json()["matched"])
        self.assertIn("ما هو AI؟", response.get_json()["answer"])

    def test_unmatched_result_can_be_returned(self) -> None:
        class NoMatchAssistant:
            def answer(self, _question: str) -> dict:
                return {
                    "matched": False,
                    "answer": "لم أجد إجابة.",
                    "source": None,
                    "similarity": None,
                }

        response = create_app(NoMatchAssistant()).test_client().post(
            "/api/chat", json={"message": "سؤال خارج قاعدة البيانات"}
        )
        self.assertEqual(response.status_code, 200)
        self.assertFalse(response.get_json()["matched"])

    def test_empty_question_is_rejected(self) -> None:
        response = self.client.post("/api/chat", json={"message": "   "})
        self.assertEqual(response.status_code, 400)

    def test_wrong_content_type_is_rejected(self) -> None:
        response = self.client.post("/api/chat", data="message=hello")
        self.assertEqual(response.status_code, 400)

    def test_question_longer_than_limit_is_rejected(self) -> None:
        response = self.client.post("/api/chat", json={"message": "س" * 501})
        self.assertEqual(response.status_code, 400)

    def test_internal_error_does_not_leak_exception(self) -> None:
        client = create_app(FailingAssistant()).test_client()
        with self.assertLogs("backend.app", level="ERROR"):
            response = client.post("/api/chat", json={"message": "سؤال صحيح"})
        self.assertEqual(response.status_code, 500)
        self.assertNotIn("private internal detail", response.get_data(as_text=True))

    def test_health_and_frontend_are_served(self) -> None:
        for path in (
            "/api/health",
            "/",
            "/public/assets/basaksehir-campus.jpg",
            "/src/scripts/main.js",
        ):
            with self.subTest(path=path):
                response = self.client.get(path)
                self.addCleanup(response.close)
                self.assertEqual(response.status_code, 200)

    def test_backend_source_is_not_publicly_served(self) -> None:
        self.assertEqual(self.client.get("/backend/config.py").status_code, 404)


if __name__ == "__main__":
    unittest.main()
