"""Flask same-origin server for the student UI and protected admin API."""
from __future__ import annotations
import inspect, os, secrets, threading, uuid
from pathlib import Path
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[1] / ".env")

from flask import Flask, jsonify, request, send_from_directory, session, redirect
from werkzeug.exceptions import RequestEntityTooLarge
from .config import *
from .db import init_db, list_documents, list_unanswered, log_unanswered, set_status, delete_document
from .rag_engine import KnowledgeBaseNotReadyError, RAGAssistant, RAGDependenciesMissingError
from .llm import LLMNotConfiguredError, LLMUnavailableError

def create_app(assistant=None):
    app=Flask(__name__); app.config.update(MAX_CONTENT_LENGTH=MAX_UPLOAD_SIZE, SECRET_KEY=os.getenv('FLASK_SECRET_KEY', secrets.token_hex(32)))
    app.json.ensure_ascii=False; loaded_assistant=assistant; lock=threading.Lock(); init_db()
    def get_assistant():
        nonlocal loaded_assistant
        if loaded_assistant is None:
            with lock:
                if loaded_assistant is None: loaded_assistant=RAGAssistant()
        return loaded_assistant
    def admin_required():
        if not ADMIN_PASSWORD: return jsonify({'ok':False,'error':'ADMIN_PASSWORD غير مضبوط في إعدادات الخادم.'}), 503
        if not session.get('admin'): return jsonify({'ok':False,'error':'يجب تسجيل الدخول كمسؤول.'}), 401
        return None
    @app.get('/')
    def home(): return send_from_directory(PROJECT_ROOT,'index.html')
    @app.get('/admin')
    def admin(): return send_from_directory(PROJECT_ROOT,'admin.html')
    @app.get('/public/assets/<path:filename>')
    def assets(filename): return send_from_directory(PROJECT_ROOT/'public/assets',filename)
    @app.get('/src/styles/<path:filename>')
    def styles(filename): return send_from_directory(PROJECT_ROOT/'src/styles',filename)
    @app.get('/src/scripts/<path:filename>')
    def scripts(filename): return send_from_directory(PROJECT_ROOT/'src/scripts',filename)
    @app.get('/manus-routes.json')
    def routes(): return send_from_directory(PROJECT_ROOT,'manus-routes.json')
    @app.get('/api/health')
    def health():
        ready=False
        if loaded_assistant is not None: ready=True
        elif VECTOR_STORE_DIR.is_dir():
            try:
                import chromadb; c=chromadb.PersistentClient(path=str(VECTOR_STORE_DIR)); ready=any(getattr(x,'count',lambda:0)()>0 for x in c.list_collections())
            except Exception: pass
        return jsonify({'status':'ok','ready':ready,'llm_configured':bool(GEMINI_API_KEY)})
    @app.get('/api/sources')
    def sources(): return jsonify({'ok':True,'sources':list_documents()})
    @app.post('/api/chat')
    def chat():
        if not request.is_json: return jsonify({'ok':False,'error':'أرسل الطلب بصيغة JSON.'}),400
        payload=request.get_json(silent=True) or {}; question=payload.get('message')
        if not isinstance(question,str) or not question.strip(): return jsonify({'ok':False,'error':'اكتب سؤالاً قبل الإرسال.'}),400
        question=question.strip()
        if len(question)>MAX_QUESTION_LENGTH: return jsonify({'ok':False,'error':f'الحد الأقصى للسؤال هو {MAX_QUESTION_LENGTH} حرفاً.'}),400
        try:
            engine = get_assistant()
            history = payload.get('history') if isinstance(payload.get('history'), list) else None
            result = engine.answer(question, history) if len(inspect.signature(engine.answer).parameters) > 1 else engine.answer(question)
        except KnowledgeBaseNotReadyError: return jsonify({'ok':False,'error':KNOWLEDGE_BASE_NOT_READY}),503
        except RAGDependenciesMissingError: return jsonify({'ok':False,'error':'اعتماديات البحث غير مثبتة. راجع README_AR.md.'}),503
        except LLMNotConfiguredError: return jsonify({'ok':False,'error':'لم يتم إعداد GEMINI_API_KEY بعد. أضف المفتاح إلى متغيرات البيئة ثم أعد تشغيل الخادم.'}),503
        except LLMUnavailableError: return jsonify({'ok':False,'error':'تعذر الوصول إلى Gemini أو انتهت الحصة. لم يتم اختراع إجابة؛ حاول لاحقاً.'}),502
        except Exception: app.logger.exception('RAG request failed'); return jsonify({'ok':False,'error':'حدث خطأ داخلي أثناء البحث.'}),500
        if not result.get('matched'):
            log_unanswered(question)
        return jsonify({'ok':True,**result}),200
    @app.post('/api/admin/login')
    def login():
        if not ADMIN_PASSWORD or not secrets.compare_digest(str(request.json.get('password','')),ADMIN_PASSWORD): return jsonify({'ok':False,'error':'بيانات الدخول غير صحيحة.'}),401
        session['admin']=True; return jsonify({'ok':True})
    @app.post('/api/admin/logout')
    def logout(): session.clear(); return jsonify({'ok':True})
    @app.get('/api/admin/stats')
    def stats():
        denied=admin_required()
        if denied:return denied
        docs=list_documents(); return jsonify({'ok':True,'documents':docs,'unanswered':list_unanswered(),'chunk_count':sum(int(d.get('chunk_count') or 0) for d in docs)})
    @app.post('/api/admin/upload')
    def upload():
        denied=admin_required()
        if denied:return denied
        file=request.files.get('file')
        if not file or not file.filename:return jsonify({'ok':False,'error':'اختر ملفاً.'}),400
        suffix=Path(file.filename).suffix.lower()
        if suffix not in ALLOWED_EXTENSIONS:return jsonify({'ok':False,'error':'الأنواع المدعومة: PDF, TXT, Markdown, JSON.'}),400
        UPLOAD_DIR.mkdir(parents=True,exist_ok=True); doc_id=uuid.uuid4().hex; path=UPLOAD_DIR/(doc_id+suffix); file.save(path)
        try:
            from .document_processor import process_document
            row=process_document(path, {'id':doc_id,'filename':file.filename,'source_name':request.form.get('source_name',''),'source_type':request.form.get('source_type','official'),'section':request.form.get('section',''),'academic_year':request.form.get('academic_year',''),'semester':request.form.get('semester',''),'status':'draft'})
            return jsonify({'ok':True,'document':row}),201
        except Exception as exc: path.unlink(missing_ok=True); return jsonify({'ok':False,'error':str(exc)}),400
    @app.post('/api/admin/documents/<doc_id>/approve')
    def approve(doc_id):
        denied=admin_required()
        if denied:return denied
        set_status(doc_id,'approved')
        try:
            import chromadb; c=chromadb.PersistentClient(path=str(VECTOR_STORE_DIR)); col=c.get_collection(DOCUMENT_COLLECTION_NAME); rows=col.get(where={'file_id':doc_id},include=['metadatas']); ids=rows.get('ids',[]); metas=[]
            for m in rows.get('metadatas',[]): metas.append({**m,'status':'approved','approved':'true'})
            if ids: col.update(ids=ids,metadatas=metas)
        except Exception: pass
        return jsonify({'ok':True})
    @app.delete('/api/admin/documents/<doc_id>')
    def remove(doc_id):
        denied=admin_required()
        if denied:return denied
        try:
            import chromadb; c=chromadb.PersistentClient(path=str(VECTOR_STORE_DIR)); col=c.get_collection(DOCUMENT_COLLECTION_NAME); rows=col.get(where={'file_id':doc_id},include=[]); ids=rows.get('ids',[]); 
            if ids: col.delete(ids=ids)
        except Exception: pass
        delete_document(doc_id); return jsonify({'ok':True})
    @app.errorhandler(RequestEntityTooLarge)
    def too_large(_): return jsonify({'ok':False,'error':'حجم الملف أكبر من الحد المسموح.'}),413
    return app
app=create_app()
if __name__=='__main__': app.run(host=os.getenv('HOST','0.0.0.0'),port=int(os.getenv('PORT','7860')))
